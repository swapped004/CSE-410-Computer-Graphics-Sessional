This release only encompasses the filter derivation and
rasterizer source code. To compile and run, please download
the full 63.3 MB release that includes all dependencies:

http://wassenberg.dreamhosters.com/LineAA.html

Contact address: jan.wassenberg@iosb.fraunhofer.DE
  (unfortunately, the wrong TLD (.org) is specified in the paper)
